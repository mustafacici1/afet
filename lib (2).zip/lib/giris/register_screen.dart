import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../widgets/animated_gradient_button.dart';
import '../theme/theme.dart';

final supabase = Supabase.instance.client;

// Model for Family Member data
class FamilyMember {
  String fullName;
  String relationship;
  int birthYear;
  String? specialNeeds;
  File? image;

  FamilyMember({
    required this.fullName,
    required this.relationship,
    required this.birthYear,
    this.specialNeeds,
    this.image,
  });
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  
  // Controllers for all fields
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _fullNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _cityController = TextEditingController();
  final _districtController = TextEditingController();
  final _neighborhoodController = TextEditingController();
  final _addressDetailController = TextEditingController();

  bool _isLoading = false;
  File? _profileImage;
  final List<FamilyMember> _familyMembers = [];

  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    // Dispose all controllers
    _animationController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _fullNameController.dispose();
    _phoneController.dispose();
    _cityController.dispose();
    _districtController.dispose();
    _neighborhoodController.dispose();
    _addressDetailController.dispose();
    super.dispose();
  }

  Future<void> _pickImage(Function(File) onImageSelected) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (pickedFile != null) {
      onImageSelected(File(pickedFile.path));
    }
  }

  Future<void> _signUp() async {
    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen formdaki hataları düzeltin.'), backgroundColor: Colors.red),
      );
      return;
    }
    
    FocusScope.of(context).unfocus();
    setState(() => _isLoading = true);

    try {
      final authResponse = await supabase.auth.signUp(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      final user = authResponse.user;

      if (user != null) {
        // 1. Upload profile picture
        String? profilePhotoUrl;
        if (_profileImage != null) {
          profilePhotoUrl = await _uploadImage(_profileImage!, user.id, 'profile_photo');
        }

        // 2. Insert main profile
        await supabase.from('profiles').insert({
          'auth_uid': user.id,
          'full_name': _fullNameController.text.trim(),
          'phone': _phoneController.text.trim(),
          'photo_url': profilePhotoUrl,
          'address_city': _cityController.text.trim(),
          'address_district': _districtController.text.trim(),
          'address_neighborhood': _neighborhoodController.text.trim(),
          'address_detail': _addressDetailController.text.trim(),
          'role': 'user',
        });

        // 3. Insert family members
        for (final member in _familyMembers) {
          String? memberPhotoUrl;
          if (member.image != null) {
            memberPhotoUrl = await _uploadImage(member.image!, user.id, 'family_${DateTime.now().millisecondsSinceEpoch}');
          }
          await supabase.from('family_members').insert({
            'profile_id': user.id, // schema implies this links to profiles.auth_uid
            'full_name': member.fullName,
            'relationship': member.relationship,
            'birth_year': member.birthYear,
            'special_needs': member.specialNeeds,
            'photo_url': memberPhotoUrl,
          });
        }

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Kayıt başarılı! Lütfen giriş yapın.'), backgroundColor: Colors.green),
          );
          Navigator.of(context).pop();
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Kayıt sırasında bir hata oluştu: ${e.toString()}'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<String?> _uploadImage(File image, String userId, String name) async {
    final String fileExt = image.path.split('.').last;
    final String fileName = '$name.$fileExt';
    final String path = 'public/$userId/$fileName';
    
    await supabase.storage.from('images').upload(path, image); // Assuming bucket is 'images'
    return supabase.storage.from('images').getPublicUrl(path);
  }

  void _showAddFamilyMemberDialog() {
    showDialog(
      context: context,
      builder: (context) => AddFamilyMemberDialog(
        onAddMember: (member) {
          setState(() {
            _familyMembers.add(member);
          });
        },
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    final theme = AppTheme.seismoDarkTheme;
    return Theme(
      data: theme,
      child: Scaffold(
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Hesap Oluştur', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('Afet anında güvende kalmak ve sevdiklerinize ulaşmak için bilgilerinizi girin.'),
                  const SizedBox(height: 24),
                  
                  Center(
                    child: GestureDetector(
                      onTap: () => _pickImage((file) => setState(() => _profileImage = file)),
                      child: CircleAvatar(
                        radius: 50,
                        backgroundImage: _profileImage != null ? FileImage(_profileImage!) : null,
                        child: _profileImage == null ? const Icon(Icons.camera_alt, size: 40) : null,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  _buildSectionTitle('Kişisel Bilgiler'),
                  _buildTextField(_fullNameController, 'Ad Soyad', Icons.person),
                  _buildTextField(_phoneController, 'Telefon Numarası', Icons.phone, keyboardType: TextInputType.phone),
                  
                  _buildSectionTitle('Adres Bilgileri'),
                  _buildTextField(_cityController, 'İl', Icons.location_city),
                  _buildTextField(_districtController, 'İlçe', Icons.map),
                  _buildTextField(_neighborhoodController, 'Mahalle', Icons.my_location),
                  _buildTextField(_addressDetailController, 'Adres Detayı (Sokak, No, Daire)', Icons.home),

                  _buildSectionTitle('Giriş Bilgileri'),
                  _buildTextField(_emailController, 'E-posta Adresi', Icons.email, keyboardType: TextInputType.emailAddress, isEmail: true),
                  _buildTextField(_passwordController, 'Şifre', Icons.lock, isPassword: true),

                  _buildSectionTitle('Aile Üyeleri'),
                  _buildFamilyMemberList(),
                  TextButton.icon(
                    icon: const Icon(Icons.add),
                    label: const Text('Aile Üyesi Ekle'),
                    onPressed: _showAddFamilyMemberDialog,
                  ),

                  const SizedBox(height: 30),
                  if (_isLoading)
                    const Center(child: CircularProgressIndicator())
                  else
                    AnimatedGradientButton(onPressed: _signUp, text: 'Kaydı Tamamla'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {bool isPassword = false, bool isEmail = false, TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword,
        keyboardType: keyboardType,
        validator: (value) {
          if (value == null || value.isEmpty) return '$label alanı boş bırakılamaz.';
          if (isEmail && !RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
            return 'Lütfen geçerli bir e-posta adresi girin.';
          }
          return null;
        },
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 20.0, bottom: 8.0),
      child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white70)),
    );
  }

  Widget _buildFamilyMemberList() {
    if (_familyMembers.isEmpty) {
      return const Text('Henüz aile üyesi eklenmedi.', style: TextStyle(color: Colors.grey));
    }
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _familyMembers.length,
      itemBuilder: (context, index) {
        final member = _familyMembers[index];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundImage: member.image != null ? FileImage(member.image!) : null,
              child: member.image == null ? const Icon(Icons.person) : null,
            ),
            title: Text(member.fullName),
            subtitle: Text(member.relationship),
            trailing: IconButton(
              icon: const Icon(Icons.delete, color: Colors.redAccent),
              onPressed: () => setState(() => _familyMembers.removeAt(index)),
            ),
          ),
        );
      },
    );
  }
}


// DIALOG WIDGET
class AddFamilyMemberDialog extends StatefulWidget {
  final Function(FamilyMember) onAddMember;
  const AddFamilyMemberDialog({super.key, required this.onAddMember});

  @override
  State<AddFamilyMemberDialog> createState() => _AddFamilyMemberDialogState();
}

class _AddFamilyMemberDialogState extends State<AddFamilyMemberDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _relationshipController = TextEditingController();
  final _birthYearController = TextEditingController();
  final _specialNeedsController = TextEditingController();
  File? _image;

  Future<void> _pickImage(Function(File) onImageSelected) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (pickedFile != null) {
      onImageSelected(File(pickedFile.path));
    }
  }

  void _addMember() {
    if (_formKey.currentState!.validate()) {
      widget.onAddMember(FamilyMember(
        fullName: _nameController.text,
        relationship: _relationshipController.text,
        birthYear: int.tryParse(_birthYearController.text) ?? 0,
        specialNeeds: _specialNeedsController.text,
        image: _image,
      ));
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Aile Üyesi Ekle'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              GestureDetector(
                onTap: () => _pickImage((file) => setState(() => _image = file)),
                child: CircleAvatar(
                  radius: 40,
                  backgroundImage: _image != null ? FileImage(_image!) : null,
                  child: _image == null ? const Icon(Icons.camera_alt, size: 30) : null,
                ),
              ),
              TextFormField(controller: _nameController, decoration: const InputDecoration(labelText: 'Ad Soyad'), validator: (v) => v!.isEmpty ? 'Zorunlu alan' : null),
              TextFormField(controller: _relationshipController, decoration: const InputDecoration(labelText: 'Yakınlık (Eş, Çocuk vb.)'), validator: (v) => v!.isEmpty ? 'Zorunlu alan' : null),
              TextFormField(controller: _birthYearController, decoration: const InputDecoration(labelText: 'Doğum Yılı'), keyboardType: TextInputType.number, validator: (v) => v!.isEmpty ? 'Zorunlu alan' : null),
              TextFormField(controller: _specialNeedsController, decoration: const InputDecoration(labelText: 'Özel Durum/Hastalık (Varsa)')),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('İptal')),
        ElevatedButton(onPressed: _addMember, child: const Text('Ekle')),
      ],
    );
  }
}